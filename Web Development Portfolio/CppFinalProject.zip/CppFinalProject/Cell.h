#pragma once
#include <iostream>
#include <string>
using namespace std;

class Cell
{
private:

    // Cell number / value
    int value;

    // Revealed
    bool revealed;
public:

    // Default Constructor
    Cell()
    {
        // Initialize a cell number
        value = 0;
        // Initialize revealed to false
        revealed = false;
    }

    // Accessors
    int getValue() const
    {
        if (!revealed)
            return -1;
        else
            return value;
    }

    int isRevealed() const
    {
        return revealed;
    }

    // Mutators

    void setValue(int num)
    {
        value = num;
    }

    void reveal()
    {
        revealed = true;
    }



};

