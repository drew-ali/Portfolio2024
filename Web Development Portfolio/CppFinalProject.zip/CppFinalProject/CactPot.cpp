#include <iostream>

#include "CactPot.h"
using namespace std;
/*

The CactPot ticket should be implemented as a dynamically allocated,
 two-dimensional array data member, of 3 by 3 integers.




 -----------------
 A lottery ticket must be loaded by RANDOMLY selecting
 one of the options available in the "cactpotTickets.txt"


 To select the ticket combination, the program will GENERATE A RANDOM VALUE
 equivalent to the line number of a ticket within the file.

 ** The program will randomly generate a number between 0 and 362,880
 ** to generate the ticket

The file contains 362,880 lines (tickets),
 and the SIZE OF EACH LINE IS 20 BYTES.

The structure of each line is as follows:
<digit1><space><digit2><space> ... <digit9><space><CR><LF>

 --------

 at end of game, system will read highestRewards.txt ( or create if does not exist)

 highestRewards.txt = Cell name and their Gold Point Rewards.
 if player has scored higher than the gold point rewards in the file, they become
 the new highest gold points rewards player.

 if player has scored the same as the gold point rewards in the file, their record will
 be appended

 otherwise, text file will remain intact.


 */



// Functions
void displayRules();
void displayRewardsLog();
void playGame();
int selectCell();

int main() {

    char again = 'Y';
    int choice;

    // Display Intro
    cout << R"(
_________                __ __________       __    .____           __    __
\_   ___ \_____    _____/  |\______   \_____/  |_  |    |    _____/  |__/  |_  ___________ ___.__.
/    \  \/\__  \ _/ ___\   __\     ___/  _ \   __\ |    |   /  _ \   __\   __\/ __ \_  __ <   |  |
\     \____/ __ \\  \___|  | |    |  (  <_> )  |   |    |__(  <_> )  |  |  | \  ___/|  | \/\___  |
 \______  (____  /\___  >__| |____|   \____/|__|   |_______ \____/|__|  |__|  \___  >__|   / ____|
        \/     \/     \/                                   \/                     \/       \/

    Welcome to the CactPot Lottery Game!
        Program by Drew, Bryce, and Hailey...
)" << '\n';


    do
    {
        // Display Menu
        cout << "Menu: "
        "\n******************************************";
        cout << "\n*\t1. See the Rules."
                "\n*\t2. Play the Game."
                "\n*\t3. See Highest Gold Point Rewards."
                "\n*\t4. Quit."
        "\n******************************************"
        "\nChoice: ";
        cin >> choice;

        // Menu
        switch(choice)
        {
            // Display Rules
            case 1: displayRules(); break;

            // Play Game
            case 2: playGame(); break;

            // See Highest Gold Point Rewards
            case 3: displayRewardsLog(); break;

            // Quit
            case 4: again = 'N'; break;

            // Error
            default: cout << "PLACEHOLDER: Error, try again.";
        }

        // Update highestRewards.txt
        // Delete array

    }while(toupper(again) == 'Y');





}


void displayRules()
{
    cout << "\nPLACEHOLDER: Display the rules" << endl << endl;
}

void displayRewardsLog()
{
    cout << "\nPLACEHOLDER: Display Highest Gold Point Rewards" << endl << endl;
}



void playGame()
{

    //TEMP - ticketNumbers array needs to be replaced with the actual ticket number generated
    int ticketNumbers[9] = {1,2,3,4,5,6,7,8,9};

    // CactPotcket into CactPot object
        //Cactpot ticket(ticketNumbers);

        CactPot ticket(ticketNumbers);

    // Display 2d array of Xs with one cell revealed at random
         if (ticket.allCellsHidden())
         {
             int cell = 3; // this number needs to be replaced with a rand generated num 1-9
             ticket.revealCell(cell);
         }
         cout << ticket;


     // User reveals 3 cells
        while(!ticket.scratchLimit())
        {
            ticket.revealCell(selectCell());
            cout << ticket;

        }

        // User chooses a row

        cout << "\nYou have revealed 3 cells. Choose a set and receive your score!" << endl;
        int rowChoice = 0;
        int rowScore = 0;

        do {
            cout << "\n******************************************";
            cout << "\n*\t1. Row 1"
                    "\n*\t2. Row 2"
                    "\n*\t3. Row 3"
                    "\n*\t4. Column 1"
                    "\n*\t5. Column 2"
                    "\n*\t6. Column 3"
                    "\n*\t7. Forward Diagonal (Top Left to Bottom Right)"
                    "\n*\t8. Rear Diagonal (Top Right to Bottom Left)"
                    "\n******************************************"
                    "\nChoice: ";
            cin >> rowChoice;
        } while(rowChoice < 1 || rowChoice > 8);

    //reveal all cells
    ticket.revealAll();
    // Get Score
    rowScore = ticket.sumRow(rowChoice);
    // Display revealed ticket
    cout << ticket;

    cout << "All sets revealed, your score was: " << rowScore << "!" << endl;
}

int selectCell()
{
    int userRowChoice, userCellChoice;

    cout << "\n-->\tPlease Select a row (1, 2 or 3): ";
    cin >> userRowChoice;

    cout << "-->\tPlease Select a cell (1, 2 or 3): ";
    cin >> userCellChoice;
    cout << endl;

    switch(userRowChoice)
    {
        // Row 1
        case 1:
            if (userCellChoice == 1)
                return 1;
            else if (userCellChoice == 2)
                return 2;
            else if (userCellChoice == 3)
                return 3;
        // Row 2
        case 2:
            if (userCellChoice == 1)
                return 4;
            else if (userCellChoice == 2)
                return 5;
            else if (userCellChoice == 3)
                return 6;
        // Row 3
        case 3:
            if (userCellChoice == 1)
                return 7;
            else if (userCellChoice == 2)
                return 8;
            else if (userCellChoice == 3)
                return 9;
    }
}
