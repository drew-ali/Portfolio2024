#pragma once
#include <string>
#include <iomanip>
#include "Cell.h"
using namespace std;





class CactPot
{
private:
    // 2d array of cells
    Cell** ticket;

    const int ROW = 3,
              COL = 3;

public:

    // Constructor
    CactPot(int* ticketNumbers)
    {
        // Create array of references
        ticket = new Cell*[ROW];

        // Allocate memory to each row of the 2D array
        for(int i = 0; i < ROW; i++)
            ticket[i] = new Cell[COL];

        // Add ticket numbers to array
        int count = 0;
        for(int i = 0; i < ROW; i++)
        {
            for (int j = 0; j < COL; j++)
            {
                ticket[i][j].setValue(ticketNumbers[count]);
                count++;
            }
        }
    }

    // Destructor
    ~CactPot()
    {
        // Delete ticket
        for (int i = 0; i < ROW; i++)
        {
            delete[] ticket[ROW];
        }
        delete[] ticket;

        cout << "\nTEST:Destroyed all arrays" << endl; // TEST******************
    }


    // Accessors
    int displayCellVal(int cellNumber)
    {
        switch(cellNumber)
        {
            case 1: return ticket[0][0].getValue();
            case 2: return ticket[0][1].getValue();
            case 3: return ticket[0][2].getValue();
            case 4: return ticket[1][0].getValue();
            case 5: return ticket[1][1].getValue();
            case 6: return ticket[1][2].getValue();
            case 7: return ticket[2][0].getValue();
            case 8: return ticket[2][1].getValue();
            case 9: return ticket[2][2].getValue();
        }
    }

    // Displays if selected cell is revealed or not
    int displayCellStat(int cellNumber)
    {
        switch(cellNumber)
        {
            case 1: return ticket[0][0].isRevealed();
            case 2: return ticket[0][1].isRevealed();
            case 3: return ticket[0][2].isRevealed();
            case 4: return ticket[1][0].isRevealed();
            case 5: return ticket[1][1].isRevealed();
            case 6: return ticket[1][2].isRevealed();
            case 7: return ticket[2][0].isRevealed();
            case 8: return ticket[2][1].isRevealed();
            case 9: return ticket[2][2].isRevealed();
        }
    }

    // checks if all cells are still hidden
    bool allCellsHidden()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (ticket[i][j].isRevealed())
                    return false;
            }
        }
        return true;
    }

    // checks if user has revealed more than 3 cells
    bool scratchLimit()
    {
        int revealCounter = 0;

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (ticket[i][j].isRevealed())
                    revealCounter++;
            }
        }

        if (revealCounter > 3)
            return true;
        else
            return false;
    }


    // Reveals a cell based on user choice
    void revealCell(int cellNumber)
    {
        string errorMessage = "ERROR: This cell has already been revealed.\n";

        switch(cellNumber)
        {
            case 1:
                if (ticket[0][0].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[0][0].reveal();
                break;

            case 2:
                if (ticket[0][1].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[0][1].reveal();
                break;

            case 3:
                if (ticket[0][2].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[0][2].reveal();
                break;

            case 4:
                if (ticket[1][0].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[1][0].reveal();
                break;

            case 5:
                if (ticket[1][1].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[1][1].reveal();
                break;

            case 6:
                if (ticket[1][2].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[1][2].reveal();
                break;

            case 7:
                if (ticket[2][0].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[2][0].reveal();
                break;

            case 8:
                if (ticket[2][1].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[2][1].reveal();
                break;

            case 9:
                if (ticket[2][2].isRevealed())
                    cout << errorMessage << endl;
                else
                    ticket[2][2].reveal();
                break;
        }
    }


/* MIGHT REMOVE
    void revealSet(int set)
    {
        switch(set)
        {
            // Horizontal Row 1
            case 1: ticket[0][0].reveal(); ticket[0][1].reveal(); ticket[0][2].reveal(); break;
                // Horizontal Row 2
            case 2: ticket[1][0].reveal(); ticket[1][1].reveal(); ticket[1][2].reveal(); break;
                // Horizontal Row 3
            case 3: ticket[2][0].reveal(); ticket[2][1].reveal(); ticket[2][2].reveal(); break;
                // Vertical Col 1
            case 4: ticket[0][0].reveal(); ticket[1][0].reveal(); ticket[2][0].reveal(); break;
                // Vertical Col 2
            case 5: ticket[0][1].reveal(); ticket[1][1].reveal(); ticket[2][1].reveal(); break;
                // Vertical Col 3
            case 6: ticket[0][2].reveal(); ticket[1][2].reveal(); ticket[2][2].reveal(); break;
                // Forward Diagonal
            case 7: ticket[0][0].reveal(); ticket[1][1].reveal(); ticket[2][2].reveal(); break;
                //Rear Diagonal
            case 8: ticket[0][2].reveal(); ticket[1][1].reveal(); ticket[2][0].reveal(); break;
        }
    }
*/


    // Returns the sum of selected row
    int sumRow(int set)
    {
        int sum = 0;
        switch(set)
        {
            // Horizontal Row 1
            case 1: sum = ticket[0][0].getValue() + ticket[0][1].getValue() + ticket[0][2].getValue(); break;
                // Horizontal Row 2
            case 2: sum = ticket[1][0].getValue() + ticket[1][1].getValue() + ticket[1][2].getValue(); break;
                // Horizontal Row 3
            case 3: sum =  ticket[2][0].getValue() + ticket[2][1].getValue() + ticket[2][2].getValue(); break;
                // Vertical Col 1
            case 4: sum =  ticket[0][0].getValue() + ticket[1][0].getValue() + ticket[2][0].getValue(); break;
                // Vertical Col 2
            case 5: sum =  ticket[0][1].getValue() + ticket[1][1].getValue() + ticket[2][1].getValue(); break;
                // Vertical Col 3
            case 6: sum =  ticket[0][2].getValue() + ticket[1][2].getValue() + ticket[2][2].getValue(); break;
                // Forward Diagonal
            case 7: sum =  ticket[0][0].getValue() + ticket[1][1].getValue() + ticket[2][2].getValue(); break;
                //Rear Diagonal
            case 8: sum =  ticket[0][2].getValue() + ticket[1][1].getValue() + ticket[2][0].getValue(); break;
        }
        return sum;
    }


    void revealAll() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                ticket[i][j].reveal();
            }
        }
    }



        // Overloaded operator
    friend ostream& operator << (ostream& ostObj, CactPot& ticketObj)
    {
        int cellCount = 1, numCount = 0, rowCount = 2;

        ostObj << "\t\t\t ** CACTPOT TICKET **\n" << endl;
        ostObj << "\t\t\tCOL 1\tCOL 2\tCOL 3\t" << endl;
        ostObj << "\t\t----------------------------" << endl << "ROW 1\t";

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                ostObj<< setw(7) << right;

                if (ticketObj.displayCellVal(cellCount) < 0)
                    ostObj << "X";
                else
                    ostObj << ticketObj.displayCellVal(cellCount);

                ostObj << "\t";
                cellCount++;
                numCount++;

                if (numCount == 3){
                    ostObj << endl << "\t\t----------------------------" << endl;
                    numCount = 0;
                    if (rowCount < 4)
                        ostObj << "ROW " << rowCount << "\t";
                        rowCount++;

                }
            }
        }
        return ostObj;
    }


};





/*







*/



